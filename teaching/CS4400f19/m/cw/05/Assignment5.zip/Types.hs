{- |
Module      :  Types
Description :  Type-checker implementation.

Maintainer  :  Ferd <f.vesely@northeastern.edu>
               Your Name <your email>
-}

{-# OPTIONS_GHC -fdefer-typed-holes -fwarn-incomplete-patterns #-}
module Types where

import Syntax

import Maps

import Debug.Trace (trace)

import SimpleTests


-- complete the definition below
typeOf :: TEnv -> Expr -> Maybe Type
typeOf tenv (Val (Bool _)) = return TyBool
typeOf tenv (Val (Num _)) = return TyInt
typeOf tenv e@(Val _) = fail ("Runtime-only value " ++ show e)
typeOf tenv (Var x) = get x tenv
typeOf tenv (Lam x t1 e) = 
  do t2 <- typeOf (add x t1 tenv) e
     return (TyArrow t1 t2)
typeOf tenv e@(App e1 e2) =
  do TyArrow t2 t1 <- typeOf tenv e1
     t2' <- typeOf tenv e2
     if t2 == t2'
        then return t1
        else fail "App"
typeOf tenv (Fix e) =
  do TyArrow t1 t2 <- typeOf tenv e
     if t1 == t2 
        then return t1
        else fail "Fix"
typeOf tenv (Let x e1 e2) = _ -- complete 
typeOf tenv (Add e1 e2) =
  do TyInt <- typeOf tenv e1
     TyInt <- typeOf tenv e2
     return TyInt

-- 14 cases to complete

typeOf _ e = error $ "typeOf undefined for " ++ show e


---------------------------- your helper functions --------------------------


----------------------------------- TESTS -----------------------------------

tests :: IO ()
tests = do
  test "|- 4 + 5 : TyInt" (typeOf empty (Add (num 4) (num 5))) (Just TyInt)

