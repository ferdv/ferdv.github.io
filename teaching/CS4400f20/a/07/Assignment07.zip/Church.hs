{- |
Module      :  Church
Description :  Church encodings of values and operations.
               Fixpoint operator.
Copyright   : (c) Ferd, 2020
              (c) <your names>

Maintainer  : f.vesely@northeastern.edu 
              <your emails>
-}


module Church where

import Lambda
import Reduce

import SimpleTestsColor (test, testSection)


-- |Abbreviation to write a lambda with multiple arguments
lam :: [Variable] -> Lambda -> Lambda
lam = flip $ foldr Lam

app :: [Lambda] -> Lambda
app es | not $ null es = foldl1 App es

test_lam_app = do
  test "lam [x, y, z] $ app [x, y, z]"
      (lam ["x", "y", "z"] $ app [Var "x", Var "y", Var "z"])
      (Lam "x" $
          Lam "y" $
              Lam "z" $
                  App (App (Var "x") (Var "y"))
                      (Var "z"))

-- |Convert a boolean to its Church encoding
toChurchBool :: Bool -> Lambda
toChurchBool = undefined                          -- TODO: complete definition

-- |Convert a boolean from its Church encoding
fromChurchBool :: Lambda -> Maybe Bool
fromChurchBool = undefined                        -- TODO: complete definition

test_bools = undefined                            -- TODO: complete tests

-- |Numerals
czero :: Lambda
czero = lam ["s", "z"] $ Var "z"

cone :: Lambda
cone = lam ["s", "z"] $ App (Var "s") (Var "z")

ctwo :: Lambda
ctwo = lam ["s", "z"] $ App (Var "s") (App (Var "s") (Var "z"))


-- |Generalized numeral: convert a given integer >= 0 to a Church numeral
toNumeral :: Integer -> Lambda
toNumeral = undefined                             -- TODO: complete definition

-- |Convert a normalized numeral into an integer. Return Nothing if the 
-- numeral cannot be converted.
fromNumeral :: Lambda -> Maybe Integer
fromNumeral = undefined                           -- TODO: complete definition

test_numerals = undefined                         -- TODO: complete tests

-- |Successor of a natural number
csucc :: Lambda
csucc = lam ["n", "s", "z"] $
    App (Var "s") (App (App (Var "n") (Var "s")) (Var "z"))

test_csucc = undefined                            -- TODO: complete tests

-- |Predecessor of a natural number
cpred :: Lambda
cpred = Lam "n" (Lam "f" (Lam "x" (
          App (
            App (
              App (Var "n") 
                  (Lam "g" (Lam "h" (
                    App (Var "h") (App (Var "g") (Var "f")))))) 
              (Lam "u" (Var "x"))) 
            (Lam "u" (Var "u")))))

test_cpred = undefined                            -- TODO: complete tests

-- |Addition on naturals
cplus :: Lambda
cplus = lam ["m", "n"] $ Var "m" `App` csucc `App` Var "n"

-- some examples of cplus 
-- notation: I use ~n for Church numeral corresponding to n
test_cplus = do
    test "(cplus ~3 ~4)"
        (fromNumeral $ normalize $ 
            App (App cplus (toNumeral 3)) (toNumeral 4))
        (Just 7)

-- |Subtraction on naturals
cminus :: Lambda
cminus = undefined                                -- TODO: complete definition 

test_cminus = undefined                           -- TODO: complete tests

-- |Multiplication on naturals
ctimes :: Lambda
ctimes = undefined                                -- TODO: complete definition 

test_ctimes = undefined                           -- TODO: complete tests

-- |Boolean and
cand :: Lambda
cand = undefined                                  -- TODO: complete definition

test_cand = undefined                             -- TODO: complete tests

-- |Boolean or
cor :: Lambda 
cor = undefined                                   -- TODO: complete definition

test_cor = undefined                              -- TODO: complete tests

-- |Boolean negation
cnot :: Lambda
cnot = undefined                                  -- TODO: complete definition

test_cnot = undefined                             -- TODO: complete tests

-- conditional expression
cifthen :: Lambda
cifthen = lam ["b", "t", "f"] $ Var "b" `App` Var "t" `App` Var "f"

test_cifthen = undefined                          -- TODO: complete tests

-- is a given numeral zero?
ciszero :: Lambda
ciszero = Lam "n" $ 
  Var "n" `App` (Lam "x" $ toChurchBool False) `App` (toChurchBool True)

test_ciszero = undefined                          -- TODO: complete tests

-- |"less or equal"
cleq :: Lambda 
cleq = lam ["m", "n"] $ ciszero `App` (cminus `App` Var "m" `App` Var "n")

test_leq = undefined                              -- TODO: complete tests

-- |"less than"
clt :: Lambda 
clt = lam ["m", "n"] $
    cand `App` (cleq `App` Var "m" `App` Var "n") 
         `App` (cnot `App` (ceq `App` Var "m" `App` Var "n"))

test_clt = undefined                              -- TODO: complete tests

-- |"greater than"
cgt :: Lambda
cgt = lam ["m", "n"] $ cnot `App` (cleq `App` Var "m" `App` Var "n")

test_cgt = undefined                              -- TODO: complete tests

-- |"equal" for natural numbers
ceq :: Lambda
ceq = lam ["m", "n"] $
    cand `App` (cleq `App` Var "m" `App` Var "n")
         `App` (cleq `App` Var "n" `App` Var "m")

test_ceq = undefined                              -- TODO: complete tests

-- |Pair constructor
cpair :: Lambda
cpair = lam ["l", "r", "s"] $ Var "s" `App` Var "l" `App` Var "r"

test_cpair = undefined                            -- TODO: complete tests

-- |Left of a pair
cleft :: Lambda
cleft = Lam "p" $ Var "p" `App` lam ["l", "r"] (Var "l")

test_cleft = undefined                            -- TODO: complete tests

-- |Right of a pair
cright :: Lambda
cright = Lam "p" $ Var "p" `App` lam ["l", "r"] (Var "r")

test_cright = undefined                           -- TODO: complete tests

-- fixpoint combinator
cfix :: Lambda
cfix = Lam "f" $
                 (Lam "x" $ Var "f" `App` (Var "x" `App` Var "x")) 
           `App` (Lam "x" $ Var "f" `App` (Var "x" `App` Var "x"))

test_cfix = undefined                             -- TODO: complete tests

allTests :: IO ()
allTests = do
    test_lam_app
    test_bools
    test_numerals
    test_csucc
    test_cpred
    test_cplus
    test_cminus
    test_ctimes
    test_cand
    test_cor
    test_cnot
    test_cifthen
    test_ciszero
    test_leq
    test_clt
    test_cgt
    test_ceq
    test_cpair
    test_cleft
    test_cright
    test_cfix

