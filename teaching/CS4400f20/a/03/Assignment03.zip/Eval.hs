{-|
Module      : Eval
Description : Semantics of protoScheme
Copyright   : (c) Ferd, 2020
                  <add your name(s)>, 2020
Maintainer  : f.vesely@northeastern
              <email1>
              <email2>

This module provides the evaluator of the protoScheme language.

-}
module Eval where

{- TODO:
 -   * Fix the type signatures and modify 'eval' and 'subst' to accommodate a 
 -     new type of values
 -   * Write tests
 -   * Write more tests
 -}

import Syntax

import qualified SExpression as S

import SimpleTests (test)


-- |Evaluates the given expression to a value.
eval :: Expr -> Maybe Integer
eval (Integer i) = Just i
eval (Var _) = Nothing
eval (Add e1 e2) = 
    case eval e1 of
         Just v1 -> 
            case eval e2 of
                 Just v2 -> Just (v1 + v2)
                 Nothing -> Nothing
         Nothing -> Nothing
eval (Sub e1 e2) = 
    case eval e1 of
         Just v1 -> 
            case eval e2 of
                 Just v2 -> Just (v1 - v2)
                 Nothing -> Nothing
         Nothing -> Nothing
eval (Mul e1 e2) = 
    case eval e1 of
         Just v1 -> 
            case eval e2 of
                 Just v2 -> Just (v1 * v2)
                 Nothing -> Nothing
         Nothing -> Nothing
eval (Div e1 e2) = 
    case eval e1 of
         Just v1 -> 
            case eval e2 of
                 Just 0 -> Nothing
                 Just v2 -> Just (v1 `div` v2)
                 Nothing -> Nothing
         Nothing -> Nothing
eval (Let x e1 e2) = 
    case eval e1 of
         Just v1 -> eval (subst x v1 e2)
         Nothing -> Nothing

test_eval = do
    test "eval: (+ 12 30)" (eval (Add (Integer 12) (Integer 30))) (Just 42)
    test "eval: (let (x (+1 2)) (* 4 x))" 
       (eval $ Let "x" (Add (Integer 1) (Integer 2)) (Mul (Integer 4) (Var "x")))
       (Just 12)



-- |Substitutes the given value for the given variable in the given expression.
subst :: Variable -> Integer -> Expr -> Expr
subst _ _ (Integer n) = Integer n
subst x v (Var y) | x == y = Integer v
                  | otherwise = Var y
subst x v (Add e1 e2) = Add (subst x v e1) (subst x v e2)
subst x v (Sub e1 e2) = Sub (subst x v e1) (subst x v e2)
subst x v (Mul e1 e2) = Mul (subst x v e1) (subst x v e2)
subst x v (Div e1 e2) = Div (subst x v e1) (subst x v e2)
subst x v (Let y e1 e2) | x == y = Let y (subst x v e1) e2
                        | otherwise = Let y (subst x v e1) (subst x v e2)


test_subst = do
    test "subst x 42 x" (subst "x" 42 (Var "x")) (Integer 42)
    test "subst x 42 y" (subst "x" 42 (Var "y")) (Var "y")


-- |Run the given protoScheme s-expression, returning an s-expression 
-- representation of the result.
runSExpression :: S.Expr -> Maybe S.Expr
runSExpression se =
    case eval (fromSExpression se) of
         Just v -> Just (valueToSExpression v)
         Nothing -> Nothing

test_runSExpression = do
    test "run: (+ 1 2)" 
        (runSExpression $ S.List [S.Symbol "+", S.Integer 1, S.Integer 2])
        (Just $ S.Integer 3)


