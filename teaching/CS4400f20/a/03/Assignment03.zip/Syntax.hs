{-|
Module      : Syntax
Description : Abstract syntax of protoScheme
Copyright   : (c) Ferd, 2020
                  <add your name(s)>, 2020
Maintainer  : f.vesely@northeastern
              <email1>
              <email2>

This module defines the abstract syntax of protoScheme and related functions.
-}
module Syntax where

{- TODO: 
 -   * Redesign the abstract syntax to accommodate floats
 -   * Complete the missing clauses in 'fromSExpression'
 -   * Implement 'toSExpression'
 -   * Fix the type and implementation of 'valueToSExpression'
 -   * Write tests & examples 
 -   * Write more test
 -}

import qualified SExpression as S

import SimpleTests (test)

-- |Variables are just strings
type Variable = String

-- |protoScheme expressions
data Expr = Integer Integer
          | Var Variable
          | Add Expr Expr
          | Sub Expr Expr
          | Mul Expr Expr
          | Div Expr Expr
          | Let Variable Expr Expr
          deriving (Eq, Show)

-- |Parse an s-expression and convert it into a protoScheme expression.
fromSExpression :: S.Expr -> Expr
fromSExpression (S.Integer i) = Integer i
fromSExpression (S.List [S.Symbol "+", e1, e2]) = 
    Add (fromSExpression e1) (fromSExpression e2)
fromSExpression (S.List [S.Symbol "-", e1, e2]) = 
    Sub (fromSExpression e1) (fromSExpression e2)
fromSExpression (S.List [S.Symbol "*", e1, e2]) = 
    Mul (fromSExpression e1) (fromSExpression e2)
fromSExpression (S.List [S.Symbol "/", e1, e2]) = 
    Div (fromSExpression e1) (fromSExpression e2)

test_fromSExpression = do
    test "fromSExpression 42" (fromSExpression $ S.Integer 42) (Integer 42)


-- |Convert a protoScheme expression into its s-expression representation
toSExpression :: Expr -> S.Expr
toSExpression _ = undefined

test_toSExpression = do
    test "toSExpression (+ 32 14)" 
        (toSExpression $ Add (Integer 32) (Integer 14))
        (S.List [S.Symbol "+", S.Integer 32, S.Integer 14])

-- |Convert an evaluation result into s-expression
valueToSExpression :: Integer -> S.Expr
valueToSExpression i = S.Integer i

test_valueToSExpression = do
    test "toSExpression 42" 
        (valueToSExpression 42)
        (S.Integer 42)


