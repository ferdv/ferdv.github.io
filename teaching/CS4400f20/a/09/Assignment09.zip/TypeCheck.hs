{-# LANGUAGE TupleSections #-}
{-|
Module      : TypeCheck
Description : A type-checker for protoScheme with type inference and let-polymorphism.
Copyright   : (c) Ferd, 2020
Maintainer  : f.vesely@northeastern

An implementation of the protoScheme type-checker.

-}
module TypeCheck where

import Types
import Maps
import Syntax
import Result

import qualified SExpression as S

import SimpleTestsColor (test, testSection)

-- |Type environments
type TyEnv = Map Variable Type

-- |Compute the type of the given expression
typeOf :: TyEnv -> Expr -> Result Type
typeOf _ (Value v) = TyBase <$> typeOfValue v
  where
    typeOfValue :: Value -> Result BaseType
    typeOfValue (Integer _) = return TyInteger
    typeOfValue (Float _) = return TyReal
    typeOfValue (Boolean _) = return TyBoolean
    typeOfValue _ = fail "Invalid value."
typeOf tenv (Var x) = 
    fromMaybe' ("Variable " ++ x ++ " is not defined") $
        get tenv x
typeOf tenv e@(Lam x [ty] body) = do -- TODO: fix this!
    ty' <- typeOf (set tenv x ty) body
    return $ TyArrow [ty, ty']
typeOf tenv (Call e1 [e2]) = do -- TODO: fix this!
    TyArrow [ty2, ty1] <- typeOf tenv e1
    ty2' <- typeOf tenv e2
    if ty2 == ty2'
        then return ty1
        else fail "Argument types do not match"
typeOf tenv (Pair e1 e2) = do
    ty1 <- typeOf tenv e1
    ty2 <- typeOf tenv e2
    return $ TyPair ty1 ty2
typeOf tenv (PLeft e) = do 
    TyPair ty1 _ <- typeOf tenv e
    return ty1
typeOf tenv (PRight e) = do
    TyPair _ ty2 <- typeOf tenv e
    return ty2
typeOf tenv _ = undefined


-- |Compute the type of the given program, relative to the given type environment
typeOfProgram :: TyEnv -> Program -> Result Type
typeOfProgram _ _ = undefined -- TODO: complete

-- |Compute the 
typeOfProgramSExpr :: [S.Expr] -> Result S.Expr
typeOfProgramSExpr sexprs = do
    prog <- programFromSExpressions sexprs  -- TODO? you might need to change this
    typ <- typeOfProgram tyBase prog 
    return $ Types.toSExpression typ

tyBase = empty -- TODO: complete 

