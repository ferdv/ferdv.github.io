



import Parser
import SimpleTestsColor

import qualified SExpression as S


tests :: IO ()
tests = do
    file <- id =<< fromFile "example1.pss" -- :: [S.Expr]
    test "just a test" (head file) 
        (S.List [ S.Symbol "even?", S.Symbol ":", S.List [S.Symbol "->", S.Symbol "Integer", S.Symbol "Boolean" ]])

fromFile :: String -> IO (IO [S.Expr])

-- a = IO [S.Expr]
(>>=) :: IO (IO [S.Expr]) -> (IO [S.Expr] -> IO [S.Expr]) -> IO [S.Expr]

id :: IO [S.Expr] -> IO [S.Expr]
id x = x

Control.Monad :

join :: Monad m => m (m a) -> m a
join x = x >>= id





